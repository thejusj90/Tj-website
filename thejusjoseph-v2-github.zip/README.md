# ThejusJoseph.in — V2

Static GitHub Pages build.

## What changed
- Multi-page information architecture: Home, About, Work, Expertise, Insights, Contact
- Detailed case studies for Techjeeva, T-Hub/Lab32 and FiiRE/TourismTech
- Real supplied portrait used for the hero — no AI-generated portrait
- Separate assets for faster caching and easier future WordPress migration
- SEO metadata, Open Graph, Twitter card, Person schema, sitemap, robots.txt and 404 page
- Responsive editorial design

## Deploy
Upload the contents of this folder to the root of the GitHub Pages repository.

## Before public launch
Edit `/contact/index.html` and add the public email / LinkedIn URL you want visitors to use.

## WordPress migration later
The current section structure maps cleanly to native WordPress blocks/patterns and custom post types.
